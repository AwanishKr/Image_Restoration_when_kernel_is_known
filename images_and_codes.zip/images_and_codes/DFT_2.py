import numpy as np

def dft(input_seq):
    rows, cols = input_seq.shape
    print("shape of input_seq", input_seq.shape)
    dft_sequence = np.zeros((rows, cols), np.complex128)
    
    for u in range(rows):
        for v in range(cols):
        	for x in range(rows):
        		for y in range(cols):
        			dft_sequence[u][v] = dft_sequence[u][v] + input_seq[x][y]*np.exp((-2j*np.pi)*(float(u*x)/rows+float(v*y)/cols))

	return dft_sequence    

if __name__ == '__main__':
    input_array = np.array([[0,2,3],
    					    [0,3,4],
    					    [0,2,2],
    					    [1,0,0]], np.float64)
    print("shape of input_array", input_array.shape)
    received_dft = dft(input_array)
    print("\n")
    for i in range(received_dft.shape[0]):
    	for j in range(received_dft.shape[1]):
    		print(received_dft[i][j])
    
